
-- Documents table: stores uploaded files metadata
CREATE TABLE public.documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_size BIGINT NOT NULL DEFAULT 0,
  file_type TEXT NOT NULL DEFAULT 'unknown',
  source_type TEXT NOT NULL CHECK (source_type IN ('email', 'transcript', 'chat', 'demo')),
  dataset_name TEXT,
  storage_path TEXT,
  status TEXT NOT NULL DEFAULT 'uploaded' CHECK (status IN ('uploading', 'uploaded', 'processing', 'processed', 'error')),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own documents" ON public.documents FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own documents" ON public.documents FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own documents" ON public.documents FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own documents" ON public.documents FOR DELETE USING (auth.uid() = user_id);

-- Pipelines table
CREATE TABLE public.pipelines (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  project_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'ingesting', 'filtering', 'extracting', 'generating', 'validating', 'complete', 'error')),
  current_step INT NOT NULL DEFAULT 0,
  total_steps INT NOT NULL DEFAULT 6,
  progress REAL NOT NULL DEFAULT 0,
  latency_ms INT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pipelines ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pipelines" ON public.pipelines FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own pipelines" ON public.pipelines FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own pipelines" ON public.pipelines FOR UPDATE USING (auth.uid() = user_id);

-- Pipeline documents junction
CREATE TABLE public.pipeline_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  pipeline_id UUID NOT NULL REFERENCES public.pipelines(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  UNIQUE(pipeline_id, document_id)
);

ALTER TABLE public.pipeline_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage pipeline_documents" ON public.pipeline_documents
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.pipelines WHERE id = pipeline_id AND user_id = auth.uid())
  );

-- BRDs table
CREATE TABLE public.brds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  pipeline_id UUID REFERENCES public.pipelines(id),
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'generating', 'complete', 'error')),
  version INT NOT NULL DEFAULT 1,
  content JSONB DEFAULT '{}',
  accuracy REAL,
  precision_score REAL,
  recall_score REAL,
  f1_score REAL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.brds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own brds" ON public.brds FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own brds" ON public.brds FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own brds" ON public.brds FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own brds" ON public.brds FOR DELETE USING (auth.uid() = user_id);

-- Storage bucket for uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);

CREATE POLICY "Users can upload own documents" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view own documents" ON storage.objects FOR SELECT
  USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own documents" ON storage.objects FOR DELETE
  USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_pipelines_updated_at BEFORE UPDATE ON public.pipelines FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_brds_updated_at BEFORE UPDATE ON public.brds FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for pipelines
ALTER PUBLICATION supabase_realtime ADD TABLE public.pipelines;
