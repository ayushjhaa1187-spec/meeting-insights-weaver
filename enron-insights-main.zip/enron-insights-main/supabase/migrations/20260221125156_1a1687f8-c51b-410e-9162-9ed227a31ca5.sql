
-- Add 'demo' to the source_type check constraint
ALTER TABLE public.documents DROP CONSTRAINT IF EXISTS documents_source_type_check;
ALTER TABLE public.documents ADD CONSTRAINT documents_source_type_check CHECK (source_type IN ('email', 'transcript', 'chat', 'demo'));
