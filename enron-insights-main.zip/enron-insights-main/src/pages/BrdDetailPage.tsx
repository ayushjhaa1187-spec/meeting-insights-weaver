import { motion } from "framer-motion";
import { CheckCircle, Activity, Clock, ArrowLeft, Download, Share2 } from "lucide-react";
import { Link, useParams } from "react-router-dom";

const pipelineSteps = [
  { name: "Ingestion", status: "done" as const },
  { name: "Noise Filtering", status: "done" as const },
  { name: "Entity Extraction", status: "done" as const },
  { name: "BRD Generation", status: "done" as const },
  { name: "Validation", status: "done" as const },
];

const sections = [
  {
    title: "1. Project Overview",
    content:
      "This BRD defines the requirements for the Project Alpha initiative, aimed at modernizing internal communication workflows. The project leverages NLP-based analysis of historical email data (Enron dataset) and meeting transcripts (AMI corpus) to extract actionable business requirements.",
  },
  {
    title: "2. Stakeholders",
    content:
      "• Product Manager — Oversees project scope and deliverables\n• Engineering Lead — Technical architecture and implementation\n• Data Science Team — Model training and validation\n• Compliance Officer — Ensures data handling meets regulatory standards\n• End Users — Customer support and operations teams",
  },
  {
    title: "3. Functional Requirements",
    content:
      "FR-001: System shall parse email threads and extract key discussion topics with ≥90% accuracy.\nFR-002: System shall identify stakeholder mentions and map organizational roles.\nFR-003: Meeting transcripts shall be segmented by agenda item automatically.\nFR-004: Generated BRD sections must follow IEEE 830 structure.\nFR-005: Real-time streaming of BRD generation progress via WebSocket.",
  },
  {
    title: "4. Non-Functional Requirements",
    content:
      "NFR-001: Processing latency shall not exceed 10 seconds per document.\nNFR-002: System shall handle concurrent processing of up to 50 documents.\nNFR-003: All data at rest encrypted with AES-256.\nNFR-004: API response time < 200ms for dashboard queries.",
  },
  {
    title: "5. Risks",
    content:
      "• Data quality variance in legacy email formats may reduce extraction accuracy.\n• LLM hallucination risk during BRD section generation — mitigated by validation pipeline.\n• Meeting transcript noise levels may exceed 30% in some corpora.",
  },
  {
    title: "6. Success Metrics",
    content:
      "• Accuracy ≥ 95% on entity extraction benchmarks\n• Precision ≥ 92% on requirement classification\n• End-to-end pipeline latency < 8s per document\n• User satisfaction score ≥ 4.2/5.0",
  },
];

export default function BrdDetailPage() {
  const { id } = useParams();

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/brds" className="h-8 w-8 rounded-md hover:bg-muted flex items-center justify-center">
            <ArrowLeft className="h-4 w-4 text-muted-foreground" />
          </Link>
          <div>
            <h1 className="page-header">Live BRD Document</h1>
            <p className="page-subtitle flex items-center gap-2">
              {id}
              <span className="inline-flex items-center gap-1 rounded-full bg-success/10 text-success px-2 py-0.5 text-xs font-medium">
                <CheckCircle className="h-3 w-3" /> Complete
              </span>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="h-8 px-3 rounded-md border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors inline-flex items-center gap-1.5">
            <Share2 className="h-3.5 w-3.5" /> Share
          </button>
          <button className="h-8 px-3 rounded-md border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors inline-flex items-center gap-1.5">
            <Download className="h-3.5 w-3.5" /> Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Pipeline sidebar */}
        <div className="bg-card rounded-lg border shadow-sm p-5 lg:col-span-1 h-fit">
          <h2 className="text-sm font-semibold text-foreground mb-3">Pipeline Status</h2>
          <div className="space-y-1">
            {pipelineSteps.map((step) => (
              <div
                key={step.name}
                className={`pipeline-step ${
                  step.status === "done" ? "pipeline-step-done" : step.status === "active" ? "pipeline-step-active" : "pipeline-step-pending"
                }`}
              >
                {step.status === "done" ? (
                  <CheckCircle className="h-3.5 w-3.5 flex-shrink-0" />
                ) : step.status === "active" ? (
                  <Activity className="h-3.5 w-3.5 flex-shrink-0 animate-pulse-soft" />
                ) : (
                  <Clock className="h-3.5 w-3.5 flex-shrink-0" />
                )}
                {step.name}
              </div>
            ))}
          </div>
        </div>

        {/* BRD Content */}
        <div className="lg:col-span-3 bg-card rounded-lg border shadow-sm p-6 space-y-6">
          <div className="border-b pb-4">
            <h2 className="text-lg font-bold text-foreground">Project Alpha — Business Requirements Document</h2>
            <p className="text-xs text-muted-foreground mt-1">Version 3 • Generated 2026-02-20 • Accuracy: 97%</p>
          </div>
          {sections.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
            >
              <h3 className="text-sm font-semibold text-foreground mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">{s.content}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
