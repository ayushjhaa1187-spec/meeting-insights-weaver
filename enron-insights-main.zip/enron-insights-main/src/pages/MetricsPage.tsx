import { motion } from "framer-motion";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const metricCards = [
  { label: "Accuracy", value: "92.4%", sub: "Avg across all BRDs" },
  { label: "Precision", value: "92.5%", sub: "Entity extraction" },
  { label: "Recall", value: "92.6%", sub: "Requirement capture" },
  { label: "F1 Score", value: "71%", sub: "Harmonic mean" },
];

const accuracyTrend = [
  { date: "Jan", value: 88 }, { date: "Feb", value: 89 }, { date: "Mar", value: 91 },
  { date: "Apr", value: 90 }, { date: "May", value: 92 }, { date: "Jun", value: 93 },
  { date: "Jul", value: 92 }, { date: "Aug", value: 94 }, { date: "Sep", value: 93 },
  { date: "Oct", value: 95 }, { date: "Nov", value: 94 }, { date: "Dec", value: 95 },
];

const noiseRemoval = [
  { label: "Enron Emails", removed: 32, kept: 68 },
  { label: "AMI Transcripts", removed: 18, kept: 82 },
  { label: "Chat Logs", removed: 25, kept: 75 },
  { label: "Mixed Sources", removed: 22, kept: 78 },
];

const latencyDist = [
  { range: "0-2s", count: 12 }, { range: "2-4s", count: 28 }, { range: "4-6s", count: 45 },
  { range: "6-8s", count: 35 }, { range: "8-10s", count: 18 }, { range: "10s+", count: 5 },
];

export default function MetricsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-header">System Performance</h1>
        <p className="page-subtitle">Accuracy, precision, recall & latency metrics</p>
      </div>

      {/* Top metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metricCards.map((m, i) => (
          <motion.div
            key={m.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="stat-card text-center"
          >
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{m.label}</p>
            <p className="text-3xl font-bold text-foreground mt-1">{m.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{m.sub}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Accuracy trend */}
        <div className="bg-card rounded-lg border shadow-sm p-5">
          <h2 className="text-sm font-semibold text-foreground mb-4">Accuracy Trend (12 months)</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={accuracyTrend}>
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <YAxis domain={[85, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="hsl(221,83%,53%)" strokeWidth={2} dot={{ r: 3, fill: "hsl(221,83%,53%)" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Latency distribution */}
        <div className="bg-card rounded-lg border shadow-sm p-5">
          <h2 className="text-sm font-semibold text-foreground mb-4">Latency Distribution</h2>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={latencyDist}>
                <XAxis dataKey="range" axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="count" fill="hsl(221,83%,53%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Noise removal table */}
      <div className="bg-card rounded-lg border shadow-sm">
        <div className="px-5 py-4 border-b">
          <h2 className="text-sm font-semibold text-foreground">Noise Removal by Source</h2>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted/30">
              <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Source</th>
              <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Noise Removed</th>
              <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Relevant Kept</th>
              <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Ratio</th>
            </tr>
          </thead>
          <tbody>
            {noiseRemoval.map((r) => (
              <tr key={r.label} className="border-b last:border-0">
                <td className="px-5 py-3 font-medium text-foreground">{r.label}</td>
                <td className="px-5 py-3 text-destructive">{r.removed}%</td>
                <td className="px-5 py-3 text-success">{r.kept}%</td>
                <td className="px-5 py-3">
                  <div className="w-32 h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${r.kept}%` }} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
