import { motion } from "framer-motion";
import { FileText, CheckCircle, Clock, Activity, ArrowUpRight, Search } from "lucide-react";
import { Link } from "react-router-dom";

const brds = [
  { id: "brd-001", name: "Project Alpha", status: "Complete", accuracy: "97%", version: 3, updated: "2026-02-20" },
  { id: "brd-002", name: "Nemo Q1 Review", status: "Stalled", accuracy: "89%", version: 1, updated: "2026-02-18" },
  { id: "brd-003", name: "Hydra Initiative", status: "Complete", accuracy: "93%", version: 2, updated: "2026-02-16" },
  { id: "brd-004", name: "Orion Communications", status: "Processing", accuracy: "—", version: 1, updated: "2026-02-21" },
  { id: "brd-005", name: "Titan Onboarding", status: "Complete", accuracy: "96%", version: 4, updated: "2026-02-14" },
  { id: "brd-006", name: "Mercury Analytics", status: "Complete", accuracy: "91%", version: 2, updated: "2026-02-10" },
];

const statusBadge = (status: string) => {
  const cls =
    status === "Complete"
      ? "bg-success/10 text-success"
      : status === "Processing"
      ? "bg-primary/10 text-primary"
      : "bg-warning/10 text-warning";
  const Icon = status === "Complete" ? CheckCircle : status === "Processing" ? Activity : Clock;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}>
      <Icon className={`h-3 w-3 ${status === "Processing" ? "animate-pulse-soft" : ""}`} />
      {status}
    </span>
  );
};

export default function BrdsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-header">BRDs</h1>
          <p className="page-subtitle">All generated Business Requirements Documents</p>
        </div>
        <Link
          to="/upload"
          className="h-9 px-4 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"
        >
          + New BRD
        </Link>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
        <input placeholder="Search BRDs..." className="h-9 w-full rounded-md border bg-card pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {brds.map((b, i) => (
          <motion.div
            key={b.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <Link
              to={`/brds/${b.id}`}
              className="stat-card block group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                  <FileText className="h-4 w-4 text-primary" />
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <p className="text-sm font-semibold text-foreground">{b.name}</p>
              <div className="flex items-center gap-3 mt-2">
                {statusBadge(b.status)}
                <span className="text-xs text-muted-foreground">v{b.version}</span>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t text-xs text-muted-foreground">
                <span>Accuracy: {b.accuracy}</span>
                <span>{b.updated}</span>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
