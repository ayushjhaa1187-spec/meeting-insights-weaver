import { useState } from "react";

const tabs = ["Model", "Pipeline", "Export", "Team"] as const;

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<typeof tabs[number]>("Model");

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="page-header">Settings</h1>
        <p className="page-subtitle">Configure your BRD generation pipeline</p>
      </div>

      <div className="flex gap-1 border-b">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setActiveTab(t)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {activeTab === "Model" && (
        <div className="space-y-5">
          <SettingRow label="Model Provider" description="LLM used for BRD generation">
            <select className="h-9 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring">
              <option>OpenAI GPT-4o</option>
              <option>Anthropic Claude 3.5</option>
              <option>Google Gemini Pro</option>
            </select>
          </SettingRow>
          <SettingRow label="Temperature" description="Controls randomness (0 = deterministic, 1 = creative)">
            <input type="number" defaultValue={0.2} min={0} max={1} step={0.1} className="h-9 w-20 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </SettingRow>
          <SettingRow label="Max Tokens per BRD" description="Maximum tokens for generated output">
            <input type="number" defaultValue={4096} className="h-9 w-24 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </SettingRow>
          <SettingRow label="Noise Threshold" description="Relevance score below which content is filtered">
            <input type="number" defaultValue={0.3} min={0} max={1} step={0.05} className="h-9 w-20 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </SettingRow>
        </div>
      )}

      {activeTab === "Pipeline" && (
        <div className="space-y-5">
          <SettingRow label="Parallel Workers" description="Number of Celery workers for processing">
            <input type="number" defaultValue={4} min={1} max={16} className="h-9 w-20 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </SettingRow>
          <SettingRow label="Retry Limit" description="Max retries per pipeline task">
            <input type="number" defaultValue={3} min={0} max={10} className="h-9 w-20 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </SettingRow>
          <SettingRow label="Task Timeout (s)" description="Timeout per task in seconds">
            <input type="number" defaultValue={120} className="h-9 w-24 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
          </SettingRow>
        </div>
      )}

      {activeTab === "Export" && (
        <div className="space-y-5">
          <SettingRow label="Default Format" description="File format for BRD exports">
            <select className="h-9 rounded-md border bg-card px-3 text-sm outline-none focus:ring-2 focus:ring-ring">
              <option>PDF</option>
              <option>DOCX</option>
              <option>Markdown</option>
              <option>JSON</option>
            </select>
          </SettingRow>
          <SettingRow label="Include Metrics" description="Append accuracy metrics to exports">
            <input type="checkbox" defaultChecked className="h-4 w-4 rounded border accent-primary" />
          </SettingRow>
        </div>
      )}

      {activeTab === "Team" && (
        <div className="bg-card rounded-lg border p-6 text-center">
          <p className="text-sm text-muted-foreground">Team management coming soon.</p>
        </div>
      )}
    </div>
  );
}

function SettingRow({ label, description, children }: { label: string; description: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between py-3 border-b last:border-0">
      <div>
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      {children}
    </div>
  );
}
