import { motion } from "framer-motion";
import { FileText, Activity, CheckCircle, Clock, TrendingUp, Zap, ArrowUpRight } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const stats = [
  { label: "Total BRDs", value: "24", icon: FileText, change: "+3 this week", color: "text-primary" },
  { label: "Active Pipelines", value: "5", icon: Activity, change: "2 processing", color: "text-info" },
  { label: "Avg Accuracy", value: "95%", icon: TrendingUp, change: "+2.1% vs last month", color: "text-success" },
  { label: "Documents Processed", value: "150K", icon: Zap, change: "12K today", color: "text-warning" },
];

const recentBrds = [
  { name: "Project Alpha", status: "Complete", accuracy: "97%", latency: "7,000ms", updated: "1 day ago" },
  { name: "Nemo Q1 Review", status: "Stalled", accuracy: "89%", latency: "8,500ms", updated: "3 days ago" },
  { name: "Hydra Initiative", status: "Complete", accuracy: "93%", latency: "6,200ms", updated: "5 days ago" },
  { name: "Orion Communications", status: "Processing", accuracy: "—", latency: "—", updated: "Just now" },
];

const noiseData = [
  { name: "Relevant", value: 80 },
  { name: "Noise", value: 20 },
];
const COLORS = ["hsl(221,83%,53%)", "hsl(214,20%,90%)"];

const pipelineSteps = [
  { name: "Ingest", status: "done" },
  { name: "Filter", status: "done" },
  { name: "Extract", status: "active" },
  { name: "Generate", status: "pending" },
  { name: "Validate", status: "pending" },
];

const latencyData = [
  { name: "Mon", ms: 6200 }, { name: "Tue", ms: 7100 }, { name: "Wed", ms: 5800 },
  { name: "Thu", ms: 8400 }, { name: "Fri", ms: 7000 }, { name: "Sat", ms: 6500 }, { name: "Sun", ms: 5900 },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-header">Dashboard</h1>
        <p className="page-subtitle">Monitor your AI requirement intelligence pipeline</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="stat-card"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{s.label}</span>
              <s.icon className={`h-4 w-4 ${s.color}`} />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.change}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Recent BRDs */}
        <div className="lg:col-span-2 bg-card rounded-lg border shadow-sm">
          <div className="flex items-center justify-between px-5 py-4 border-b">
            <h2 className="text-sm font-semibold text-foreground">Recent BRDs</h2>
            <button className="text-xs font-medium text-primary flex items-center gap-1 hover:underline">
              View all <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/30">
                  <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Name</th>
                  <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Status</th>
                  <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Accuracy</th>
                  <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Latency</th>
                  <th className="px-5 py-2.5 text-left font-medium text-muted-foreground">Updated</th>
                </tr>
              </thead>
              <tbody>
                {recentBrds.map((b) => (
                  <tr key={b.name} className="border-b last:border-0 hover:bg-muted/20 transition-colors">
                    <td className="px-5 py-3 font-medium text-foreground">{b.name}</td>
                    <td className="px-5 py-3">
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ${
                          b.status === "Complete"
                            ? "bg-success/10 text-success"
                            : b.status === "Processing"
                            ? "bg-primary/10 text-primary"
                            : "bg-warning/10 text-warning"
                        }`}
                      >
                        {b.status === "Complete" ? (
                          <CheckCircle className="h-3 w-3" />
                        ) : b.status === "Processing" ? (
                          <Activity className="h-3 w-3 animate-pulse-soft" />
                        ) : (
                          <Clock className="h-3 w-3" />
                        )}
                        {b.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-muted-foreground">{b.accuracy}</td>
                    <td className="px-5 py-3 text-muted-foreground">{b.latency}</td>
                    <td className="px-5 py-3 text-muted-foreground">{b.updated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Noise Filtering + Pipeline */}
        <div className="space-y-4">
          <div className="bg-card rounded-lg border shadow-sm p-5">
            <h2 className="text-sm font-semibold text-foreground mb-3">Noise Filtering Stats</h2>
            <div className="h-36 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={noiseData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" strokeWidth={0}>
                    {noiseData.map((_, i) => (
                      <Cell key={i} fill={COLORS[i]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-4 text-xs">
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary" />Relevant 80%</span>
              <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-border" />Noise 20%</span>
            </div>
          </div>

          <div className="bg-card rounded-lg border shadow-sm p-5">
            <h2 className="text-sm font-semibold text-foreground mb-3">Active Pipeline</h2>
            <p className="text-xs text-muted-foreground mb-3">Project: Orion Communications</p>
            <div className="space-y-1">
              {pipelineSteps.map((step) => (
                <div
                  key={step.name}
                  className={`pipeline-step ${
                    step.status === "done" ? "pipeline-step-done" : step.status === "active" ? "pipeline-step-active" : "pipeline-step-pending"
                  }`}
                >
                  {step.status === "done" ? (
                    <CheckCircle className="h-3.5 w-3.5" />
                  ) : step.status === "active" ? (
                    <Activity className="h-3.5 w-3.5 animate-pulse-soft" />
                  ) : (
                    <Clock className="h-3.5 w-3.5" />
                  )}
                  {step.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Latency Chart */}
      <div className="bg-card rounded-lg border shadow-sm p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">Avg Processing Latency (ms)</h2>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={latencyData}>
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="ms" fill="hsl(221,83%,53%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
