import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mail, FileText, MessageSquare, Database, Upload as UploadIcon,
  X, CheckCircle, Clock, Loader2, AlertCircle, Trash2, Play,
} from "lucide-react";
import { useFileUpload, type UploadFile } from "@/hooks/useFileUpload";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";

const dataSources = [
  {
    icon: Mail,
    label: "Email Upload",
    desc: "Enron Email Dataset (.csv, .txt, .eml)",
    sourceType: "email" as const,
    dataset: "enron",
    datasetInfo: "From Kaggle: wcukierski/enron-email-dataset",
  },
  {
    icon: FileText,
    label: "Transcript Upload",
    desc: "AMI Meeting Corpus transcripts (.txt, .json)",
    sourceType: "transcript" as const,
    dataset: "ami",
    datasetInfo: "HuggingFace: knkarthick/AMI • CC BY 4.0",
  },
  {
    icon: MessageSquare,
    label: "Meeting Transcripts",
    desc: "Kaggle Meeting Transcripts Dataset",
    sourceType: "transcript" as const,
    dataset: "meeting_transcripts",
    datasetInfo: "Kaggle: abhishekunnam/meeting-transcripts",
  },
  {
    icon: Database,
    label: "Use Demo Dataset",
    desc: "Pre-loaded samples from all 3 datasets",
    sourceType: "email" as const,
    dataset: "demo",
    datasetInfo: "Enron + AMI + Meeting Transcripts samples",
  },
];

function formatSize(bytes: number) {
  if (bytes === 0) return "—";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

export default function UploadPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { files, isUploading, addFiles, removeFile, clearCompleted, uploadAll, addDemoDataset } = useFileUpload();
  const [isDragging, setIsDragging] = useState(false);
  const [loadingDemo, setLoadingDemo] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    if (dragCounter.current === 0) setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounter.current = 0;
      setIsDragging(false);
      if (e.dataTransfer.files.length > 0) {
        addFiles(e.dataTransfer.files);
      }
    },
    [addFiles]
  );

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
        addFiles(e.target.files);
        e.target.value = "";
      }
    },
    [addFiles]
  );

  const handleDemoDataset = useCallback(
    async (dataset: string) => {
      if (!user) {
        navigate("/auth");
        return;
      }
      setLoadingDemo(dataset);
      try {
        await addDemoDataset(dataset);
      } catch (err) {
        console.error(err);
      } finally {
        setLoadingDemo(null);
      }
    },
    [addDemoDataset, user, navigate]
  );

  const handleStartProcessing = useCallback(() => {
    if (!user) {
      navigate("/auth");
      return;
    }
    uploadAll();
  }, [uploadAll, user, navigate]);

  const queuedCount = files.filter((f) => f.status === "queued").length;
  const completedCount = files.filter((f) => f.status === "complete").length;
  const errorCount = files.filter((f) => f.status === "error").length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-header">Upload Data Sources</h1>
        <p className="page-subtitle">
          Upload emails, transcripts, or chat logs for BRD generation. Supported datasets: Enron Email, AMI Meeting Corpus, Meeting Transcripts.
        </p>
      </div>

      {/* Source cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {dataSources.map((s, i) => (
          <motion.button
            key={s.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            onClick={() => {
              if (s.dataset === "demo") {
                handleDemoDataset(s.dataset);
              } else {
                fileInputRef.current?.click();
              }
            }}
            disabled={loadingDemo === s.dataset}
            className="stat-card text-left group cursor-pointer hover:border-primary/40 disabled:opacity-50"
          >
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
              {loadingDemo === s.dataset ? (
                <Loader2 className="h-5 w-5 text-primary animate-spin" />
              ) : (
                <s.icon className="h-5 w-5 text-primary" />
              )}
            </div>
            <p className="text-sm font-semibold text-foreground">{s.label}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.desc}</p>
            <p className="text-[10px] text-muted-foreground/60 mt-2 leading-tight">{s.datasetInfo}</p>
          </motion.button>
        ))}
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".csv,.txt,.json,.eml,.msg,.tsv"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Drop zone */}
      <div
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`bg-card rounded-lg border-2 border-dashed transition-all cursor-pointer p-10 flex flex-col items-center justify-center text-center ${
          isDragging
            ? "border-primary bg-primary/5 scale-[1.01]"
            : "border-primary/30 hover:border-primary/50"
        }`}
      >
        <UploadIcon className={`h-8 w-8 mb-3 transition-colors ${isDragging ? "text-primary" : "text-primary/50"}`} />
        <p className="text-sm font-medium text-foreground">
          {isDragging ? "Drop files here" : "Drag & drop files here"}
        </p>
        <p className="text-xs text-muted-foreground mt-1">or click to browse • CSV, TXT, JSON, EML, TSV supported • Max 50MB per file</p>
      </div>

      {/* Upload Queue */}
      {files.length > 0 && (
        <div className="bg-card rounded-lg border shadow-sm">
          <div className="flex items-center justify-between px-5 py-4 border-b">
            <div className="flex items-center gap-3">
              <h2 className="text-sm font-semibold text-foreground">Upload Queue</h2>
              <div className="flex items-center gap-2 text-xs">
                {queuedCount > 0 && (
                  <span className="rounded-full bg-muted px-2 py-0.5 text-muted-foreground">{queuedCount} queued</span>
                )}
                {completedCount > 0 && (
                  <span className="rounded-full bg-success/10 px-2 py-0.5 text-success">{completedCount} done</span>
                )}
                {errorCount > 0 && (
                  <span className="rounded-full bg-destructive/10 px-2 py-0.5 text-destructive">{errorCount} failed</span>
                )}
              </div>
            </div>
            {completedCount > 0 && (
              <button onClick={clearCompleted} className="text-xs text-muted-foreground hover:text-foreground">
                Clear completed
              </button>
            )}
          </div>

          <div className="divide-y max-h-80 overflow-y-auto">
            <AnimatePresence>
              {files.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-center gap-4 px-5 py-3"
                >
                  <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{item.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <p className="text-xs text-muted-foreground">{formatSize(item.size)}</p>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className={`text-xs capitalize ${
                        item.sourceType === "email" ? "text-info" : item.sourceType === "chat" ? "text-warning" : "text-primary"
                      }`}>
                        {item.sourceType}
                      </span>
                    </div>
                    {item.error && (
                      <p className="text-xs text-destructive mt-0.5">{item.error}</p>
                    )}
                  </div>

                  {item.status === "uploading" && (
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <div className="w-24 h-1.5 rounded-full bg-muted overflow-hidden">
                        <motion.div
                          className="h-full bg-primary rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${item.progress}%` }}
                          transition={{ duration: 0.3 }}
                        />
                      </div>
                      <Loader2 className="h-3.5 w-3.5 text-primary animate-spin" />
                    </div>
                  )}
                  {item.status === "complete" && <CheckCircle className="h-4 w-4 text-success flex-shrink-0" />}
                  {item.status === "queued" && <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0" />}
                  {item.status === "error" && <AlertCircle className="h-4 w-4 text-destructive flex-shrink-0" />}

                  <button
                    onClick={() => removeFile(item.id)}
                    className="h-6 w-6 rounded hover:bg-muted flex items-center justify-center flex-shrink-0"
                  >
                    <X className="h-3 w-3 text-muted-foreground" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <div className="flex items-center justify-between px-5 py-4 border-t">
            <p className="text-xs text-muted-foreground">
              {files.length} file{files.length !== 1 ? "s" : ""} • {formatSize(files.reduce((sum, f) => sum + f.size, 0))} total
            </p>
            <div className="flex items-center gap-2">
              {files.length > 0 && (
                <button
                  onClick={() => files.forEach((f) => removeFile(f.id))}
                  className="h-9 px-3 rounded-md border text-sm font-medium text-muted-foreground hover:bg-muted transition-colors inline-flex items-center gap-1.5"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Clear All
                </button>
              )}
              <button
                onClick={handleStartProcessing}
                disabled={isUploading || queuedCount === 0}
                className="h-9 px-4 rounded-md bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 inline-flex items-center gap-1.5"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> Uploading...
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5" /> Start Processing
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dataset Info */}
      <div className="bg-card rounded-lg border shadow-sm p-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">Supported Datasets</h2>
        <div className="space-y-3 text-sm">
          <div className="flex items-start gap-3">
            <Mail className="h-4 w-4 text-info mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">The Enron Email Dataset</p>
              <p className="text-xs text-muted-foreground">~500K emails from Enron employees. Source: Kaggle (wcukierski/enron-email-dataset)</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <FileText className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">AMI Meeting Corpus</p>
              <p className="text-xs text-muted-foreground">Meeting transcripts + summaries. Source: HuggingFace (knkarthick/AMI) • CC BY 4.0</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <MessageSquare className="h-4 w-4 text-warning mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-foreground">Meeting Transcripts Dataset</p>
              <p className="text-xs text-muted-foreground">Community meeting transcripts. Source: Kaggle (abhishekunnam/meeting-transcripts)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
