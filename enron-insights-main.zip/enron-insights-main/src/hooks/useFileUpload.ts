import { useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface UploadFile {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  sourceType: "email" | "transcript" | "chat";
  status: "queued" | "uploading" | "complete" | "error";
  progress: number;
  error?: string;
  documentId?: string;
}

const ALLOWED_TYPES = [
  "text/csv",
  "text/plain",
  "application/json",
  "message/rfc822",
  "application/vnd.ms-outlook",
];

const ALLOWED_EXTENSIONS = [".csv", ".txt", ".json", ".eml", ".msg", ".tsv"];
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

function getSourceType(file: File): "email" | "transcript" | "chat" {
  const name = file.name.toLowerCase();
  if (name.includes("email") || name.includes("enron") || name.endsWith(".eml")) return "email";
  if (name.includes("chat") || name.includes("slack")) return "chat";
  return "transcript";
}

function validateFile(file: File): string | null {
  const ext = "." + file.name.split(".").pop()?.toLowerCase();
  if (!ALLOWED_EXTENSIONS.includes(ext)) {
    return `Unsupported file type: ${ext}. Allowed: ${ALLOWED_EXTENSIONS.join(", ")}`;
  }
  if (file.size > MAX_FILE_SIZE) {
    return `File too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Max: 50MB`;
  }
  return null;
}

export function useFileUpload() {
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const { user } = useAuth();
  const abortRef = useRef<AbortController | null>(null);

  const addFiles = useCallback((newFiles: FileList | File[]) => {
    const fileArray = Array.from(newFiles);
    const uploadFiles: UploadFile[] = [];

    for (const file of fileArray) {
      const error = validateFile(file);
      uploadFiles.push({
        id: crypto.randomUUID(),
        file,
        name: file.name,
        size: file.size,
        type: file.type || "text/plain",
        sourceType: getSourceType(file),
        status: error ? "error" : "queued",
        progress: 0,
        error: error ?? undefined,
      });
    }

    setFiles((prev) => [...prev, ...uploadFiles]);
    return uploadFiles;
  }, []);

  const removeFile = useCallback((id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }, []);

  const clearCompleted = useCallback(() => {
    setFiles((prev) => prev.filter((f) => f.status !== "complete"));
  }, []);

  const uploadAll = useCallback(async () => {
    if (!user) return;
    setIsUploading(true);

    const queued = files.filter((f) => f.status === "queued");

    for (const uf of queued) {
      // Update status to uploading
      setFiles((prev) =>
        prev.map((f) => (f.id === uf.id ? { ...f, status: "uploading" as const, progress: 10 } : f))
      );

      try {
        const storagePath = `${user.id}/${Date.now()}_${uf.name}`;

        // Upload to storage
        const { error: storageError } = await supabase.storage
          .from("documents")
          .upload(storagePath, uf.file);

        if (storageError) throw storageError;

        setFiles((prev) =>
          prev.map((f) => (f.id === uf.id ? { ...f, progress: 60 } : f))
        );

        // Create document record
        const { data, error: dbError } = await supabase
          .from("documents")
          .insert({
            user_id: user.id,
            file_name: uf.name,
            file_size: uf.size,
            file_type: uf.type,
            source_type: uf.sourceType,
            storage_path: storagePath,
            status: "uploaded",
          })
          .select("id")
          .single();

        if (dbError) throw dbError;

        setFiles((prev) =>
          prev.map((f) =>
            f.id === uf.id
              ? { ...f, status: "complete" as const, progress: 100, documentId: data.id }
              : f
          )
        );
      } catch (err: any) {
        setFiles((prev) =>
          prev.map((f) =>
            f.id === uf.id
              ? { ...f, status: "error" as const, progress: 0, error: err.message }
              : f
          )
        );
      }
    }

    setIsUploading(false);
  }, [files, user]);

  const addDemoDataset = useCallback(
    async (datasetName: string) => {
      if (!user) return;

      const { data, error } = await supabase
        .from("documents")
        .insert({
          user_id: user.id,
          file_name: `${datasetName}_demo_sample`,
          file_size: 0,
          file_type: "application/json",
          source_type: "demo" as any,
          dataset_name: datasetName,
          status: "uploaded",
          metadata: { demo: true, dataset: datasetName },
        })
        .select("id")
        .single();

      if (error) throw error;
      return data.id;
    },
    [user]
  );

  return {
    files,
    isUploading,
    addFiles,
    removeFile,
    clearCompleted,
    uploadAll,
    addDemoDataset,
  };
}
