const Index = () => {
  // Redirect handled by Landing page at "/"
  return null;
};
export default Index;
